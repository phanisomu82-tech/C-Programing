<#
.SYNOPSIS
Hostel Room Allocation & Fee Management System - Local HTTP Web Server
Pure PowerShell Built-in HTTP Server (No Node.js or Python required)
#>

$port = 8080
$url = "http://localhost:$port/"
$folder = $PSScriptRoot

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($url)

try {
    $listener.Start()
    Write-Host "==========================================================" -ForegroundColor Cyan
    Write-Host "  Hostel Room Allocation & Fee Management System" -ForegroundColor Green
    Write-Host "  University Warden & Admin Portal" -ForegroundColor White
    Write-Host "==========================================================" -ForegroundColor Cyan
    Write-Host "Server listening at: $url" -ForegroundColor Yellow
    Write-Host "Opening web application in default browser..." -ForegroundColor Gray
    Start-Process $url

    Write-Host "Press Ctrl+C to stop the server." -ForegroundColor DarkGray

    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        $localPath = $request.Url.LocalPath.TrimStart('/')
        if ([string]::IsNullOrWhiteSpace($localPath)) {
            $localPath = "index.html"
        }

        $filePath = Join-Path $folder $localPath

        if (Test-Path $filePath -PathType Leaf) {
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            $contentType = switch ($ext) {
                ".html" { "text/html; charset=utf-8" }
                ".css"  { "text/css; charset=utf-8" }
                ".js"   { "application/javascript; charset=utf-8" }
                ".json" { "application/json; charset=utf-8" }
                ".svg"  { "image/svg+xml" }
                ".png"  { "image/png" }
                default { "application/octet-stream" }
            }

            $buffer = [System.IO.File]::ReadAllBytes($filePath)
            $response.ContentType = $contentType
            $response.ContentLength64 = $buffer.Length
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
        } else {
            $response.StatusCode = 404
            $buffer = [System.Text.Encoding]::UTF8.GetBytes("404 - File Not Found: $localPath")
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
        }
        $response.Close()
    }
} catch {
    Write-Host "Server error or stopped: $_" -ForegroundColor Red
} finally {
    $listener.Stop()
    $listener.Close()
}
