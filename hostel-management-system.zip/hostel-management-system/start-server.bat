@echo off
title Hostel Management System Server
echo Starting Hostel Management System...
powershell -ExecutionPolicy Bypass -File "%~dp0start-server.ps1"
pause
