/**
 * Hostel Room Allocation & Fee Management System
 * Full-Stack Client Application & State Management
 * University Hostel Warden Portal
 */

(function () {
  'use strict';

  // =========================================================================
  // CONSTANTS & SEED DATA
  // =========================================================================
  const STORAGE_KEY = 'HOSTEL_PORTAL_DATA_V2';
  const AUTH_KEY = 'HOSTEL_PORTAL_AUTH_V2';

  const INITIAL_SEED_DATA = {
    rooms: [
      {
        id: 'R-001',
        roomNo: 'A-101',
        block: 'Block A',
        roomType: 'Single AC',
        capacity: 1,
        occupied: 1,
        annualFee: 120000,
        floor: '1st Floor',
        amenities: ['Air Conditioner', 'Attached Bathroom', 'Study Table', 'WiFi', 'Balcony'],
        createdAt: '2024-01-15T09:00:00Z'
      },
      {
        id: 'R-002',
        roomNo: 'A-102',
        block: 'Block A',
        roomType: 'Double AC',
        capacity: 2,
        occupied: 1,
        annualFee: 90000,
        floor: '1st Floor',
        amenities: ['Air Conditioner', 'Attached Bathroom', '2 Study Desks', 'WiFi'],
        createdAt: '2024-01-15T09:30:00Z'
      },
      {
        id: 'R-003',
        roomNo: 'B-201',
        block: 'Block B',
        roomType: 'Double Non-AC',
        capacity: 2,
        occupied: 2,
        annualFee: 65000,
        floor: '2nd Floor',
        amenities: ['Ceiling Fans', 'Shared Bathroom', '2 Desks', 'WiFi'],
        createdAt: '2024-01-15T10:00:00Z'
      },
      {
        id: 'R-004',
        roomNo: 'B-202',
        block: 'Block B',
        roomType: 'Triple Non-AC',
        capacity: 3,
        occupied: 1,
        annualFee: 50000,
        floor: '2nd Floor',
        amenities: ['Ceiling Fans', 'Shared Bathroom', '3 Desks', 'WiFi'],
        createdAt: '2024-01-15T10:30:00Z'
      },
      {
        id: 'R-005',
        roomNo: 'C-301',
        block: 'Block C',
        roomType: 'Double AC',
        capacity: 2,
        occupied: 0,
        annualFee: 85000,
        floor: '3rd Floor',
        amenities: ['Air Conditioner', 'Attached Bathroom', '2 Desks', 'WiFi'],
        createdAt: '2024-01-16T11:00:00Z'
      }
    ],
    students: [
      {
        id: 'S-001',
        registerNo: '2024CS101',
        fullName: 'Aarav Sharma',
        department: 'Computer Science & Engineering',
        phone: '+91 98765 43210',
        roomId: 'R-001',
        roomNo: 'A-101',
        block: 'Block A',
        roomType: 'Single AC',
        allocatedDate: '2024-07-20T10:00:00Z',
        totalFee: 120000,
        paidFee: 80000,
        balanceDue: 40000,
        feeStatus: 'Partial',
        status: 'Active',
        vacatedDate: null
      },
      {
        id: 'S-002',
        registerNo: '2024EC204',
        fullName: 'Ananya Iyer',
        department: 'Electronics & Communication',
        phone: '+91 98234 56789',
        roomId: 'R-002',
        roomNo: 'A-102',
        block: 'Block A',
        roomType: 'Double AC',
        allocatedDate: '2024-07-22T11:30:00Z',
        totalFee: 90000,
        paidFee: 90000,
        balanceDue: 0,
        feeStatus: 'Paid',
        status: 'Active',
        vacatedDate: null
      },
      {
        id: 'S-003',
        registerNo: '2024ME312',
        fullName: 'Rohan Varma',
        department: 'Mechanical Engineering',
        phone: '+91 97123 45678',
        roomId: 'R-003',
        roomNo: 'B-201',
        block: 'Block B',
        roomType: 'Double Non-AC',
        allocatedDate: '2024-07-25T09:15:00Z',
        totalFee: 65000,
        paidFee: 0,
        balanceDue: 65000,
        feeStatus: 'Pending',
        status: 'Active',
        vacatedDate: null
      },
      {
        id: 'S-004',
        registerNo: '2024EE118',
        fullName: 'Kavya Patel',
        department: 'Electrical Engineering',
        phone: '+91 98456 78901',
        roomId: 'R-003',
        roomNo: 'B-201',
        block: 'Block B',
        roomType: 'Double Non-AC',
        allocatedDate: '2024-07-26T14:20:00Z',
        totalFee: 65000,
        paidFee: 65000,
        balanceDue: 0,
        feeStatus: 'Paid',
        status: 'Active',
        vacatedDate: null
      },
      {
        id: 'S-005',
        registerNo: '2023IT405',
        fullName: 'Devraj Mukherjee',
        department: 'Information Technology',
        phone: '+91 91234 56780',
        roomId: 'R-004',
        roomNo: 'B-202',
        block: 'Block B',
        roomType: 'Triple Non-AC',
        allocatedDate: '2024-08-01T16:00:00Z',
        totalFee: 50000,
        paidFee: 25000,
        balanceDue: 25000,
        feeStatus: 'Partial',
        status: 'Active',
        vacatedDate: null
      }
    ],
    transactions: [
      {
        id: 'TXN-001',
        receiptNo: 'RCPT-8A4F2C1B',
        date: '2024-07-21T11:42:00Z',
        studentId: 'S-001',
        studentName: 'Aarav Sharma',
        registerNo: '2024CS101',
        department: 'Computer Science & Engineering',
        phone: '+91 98765 43210',
        roomId: 'R-001',
        roomNo: 'A-101',
        block: 'Block A',
        roomType: 'Single AC',
        amountPaid: 80000,
        remainingBalance: 40000,
        totalFee: 120000,
        paymentMode: 'UPI',
        transactionRef: 'UPI/SBIN/420194821092',
        remarks: '1st Installment Semester 1 Fee'
      },
      {
        id: 'TXN-002',
        receiptNo: 'RCPT-9B1D5F7A',
        date: '2024-07-23T14:15:00Z',
        studentId: 'S-002',
        studentName: 'Ananya Iyer',
        registerNo: '2024EC204',
        department: 'Electronics & Communication',
        phone: '+91 98234 56789',
        roomId: 'R-002',
        roomNo: 'A-102',
        block: 'Block A',
        roomType: 'Double AC',
        amountPaid: 90000,
        remainingBalance: 0,
        totalFee: 90000,
        paymentMode: 'Net Banking',
        transactionRef: 'HDFC-NBT-89210471',
        remarks: 'Full Annual Hostel Fee Paid'
      },
      {
        id: 'TXN-003',
        receiptNo: 'RCPT-3C7E1A9D',
        date: '2024-07-27T16:30:00Z',
        studentId: 'S-004',
        studentName: 'Kavya Patel',
        registerNo: '2024EE118',
        department: 'Electrical Engineering',
        phone: '+91 98456 78901',
        roomId: 'R-003',
        roomNo: 'B-201',
        block: 'Block B',
        roomType: 'Double Non-AC',
        amountPaid: 65000,
        remainingBalance: 0,
        totalFee: 65000,
        paymentMode: 'Debit/Credit Card',
        transactionRef: 'CARD-POS-893021',
        remarks: 'Annual Hostel Fee via Card'
      },
      {
        id: 'TXN-004',
        receiptNo: 'RCPT-7F2A4B8C',
        date: '2024-08-02T10:05:00Z',
        studentId: 'S-005',
        studentName: 'Devraj Mukherjee',
        registerNo: '2023IT405',
        department: 'Information Technology',
        phone: '+91 91234 56780',
        roomId: 'R-004',
        roomNo: 'B-202',
        block: 'Block B',
        roomType: 'Triple Non-AC',
        amountPaid: 25000,
        remainingBalance: 25000,
        totalFee: 50000,
        paymentMode: 'Cash',
        transactionRef: 'CSH-RCPT-0491',
        remarks: 'Partial Deposit paid at Warden counter'
      }
    ]
  };

  // =========================================================================
  // STATE STORE
  // =========================================================================
  const State = {
    data: null,

    init() {
      try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
          this.data = JSON.parse(stored);
        } else {
          this.resetToSeed();
        }
      } catch (err) {
        console.error('Error loading state from localStorage:', err);
        this.resetToSeed();
      }
    },

    save() {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
        App.renderAll();
      } catch (err) {
        console.error('Error saving state to localStorage:', err);
        Toast.show('Failed to save data to local storage', 'error');
      }
    },

    resetToSeed() {
      this.data = JSON.parse(JSON.stringify(INITIAL_SEED_DATA));
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
      App.renderAll();
    }
  };

  // =========================================================================
  // UTILITIES
  // =========================================================================
  const Utils = {
    formatCurrency(amount) {
      if (isNaN(amount) || amount === null) return '₹0';
      return '₹' + Number(amount).toLocaleString('en-IN');
    },

    formatDateTime(isoString) {
      if (!isoString) return 'N/A';
      try {
        const d = new Date(isoString);
        return d.toLocaleDateString('en-IN', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });
      } catch (e) {
        return isoString;
      }
    },

    generateId(prefix = 'ID') {
      const hex = Math.random().toString(16).substring(2, 8).toUpperCase();
      return `${prefix}-${hex}`;
    },

    generateReceiptNo() {
      const hex = Math.random().toString(16).substring(2, 10).toUpperCase();
      return `RCPT-${hex}`;
    },

    numberToWords(num) {
      if (num === 0) return 'Zero Rupees Only';
      if (!num || isNaN(num)) return '';

      const a = [
        '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
        'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'
      ];
      const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

      function inWords(n) {
        if (n < 20) return a[n];
        const digit = n % 10;
        return b[Math.floor(n / 10)] + (digit ? ' ' + a[digit] : '');
      }

      let words = '';
      const crore = Math.floor(num / 10000000);
      num %= 10000000;
      const lakh = Math.floor(num / 100000);
      num %= 100000;
      const thousand = Math.floor(num / 1000);
      num %= 1000;
      const hundred = Math.floor(num / 100);
      num %= 100;

      if (crore > 0) words += inWords(crore) + ' Crore ';
      if (lakh > 0) words += inWords(lakh) + ' Lakh ';
      if (thousand > 0) words += inWords(thousand) + ' Thousand ';
      if (hundred > 0) words += inWords(hundred) + ' Hundred ';
      if (num > 0) {
        if (words !== '') words += 'and ';
        words += inWords(num);
      }

      return words.trim() + ' Rupees Only';
    }
  };

  // =========================================================================
  // TOAST NOTIFICATION SERVICE
  // =========================================================================
  const Toast = {
    container: null,

    init() {
      this.container = document.getElementById('toast-container');
    },

    show(message, type = 'success') {
      if (!this.container) return;

      const toast = document.createElement('div');
      toast.className = 'toast-item pointer-events-auto flex items-start space-x-3 p-3.5 rounded-xl shadow-lg border text-xs font-medium cursor-pointer transition-all duration-300';

      let bgClasses = 'bg-white text-slate-800 border-slate-200';
      let iconSvg = '';

      if (type === 'success') {
        bgClasses = 'bg-emerald-50 text-emerald-900 border-emerald-200';
        iconSvg = `<svg class="w-5 h-5 text-emerald-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`;
      } else if (type === 'error') {
        bgClasses = 'bg-rose-50 text-rose-900 border-rose-200';
        iconSvg = `<svg class="w-5 h-5 text-rose-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`;
      } else if (type === 'warning') {
        bgClasses = 'bg-amber-50 text-amber-900 border-amber-200';
        iconSvg = `<svg class="w-5 h-5 text-amber-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>`;
      } else {
        bgClasses = 'bg-blue-50 text-blue-900 border-blue-200';
        iconSvg = `<svg class="w-5 h-5 text-blue-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`;
      }

      toast.className += ` ${bgClasses}`;
      toast.innerHTML = `
        ${iconSvg}
        <div class="flex-1 pr-2 leading-relaxed">${message}</div>
        <button class="text-slate-400 hover:text-slate-600 p-0.5">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
      `;

      const removeToast = () => {
        toast.classList.add('removing');
        setTimeout(() => toast.remove(), 250);
      };

      toast.addEventListener('click', removeToast);
      setTimeout(removeToast, 4000);

      this.container.appendChild(toast);
    }
  };

  // =========================================================================
  // AUTHENTICATION CONTROLLER
  // =========================================================================
  const Auth = {
    isLoggedIn() {
      return localStorage.getItem(AUTH_KEY) === 'true';
    },

    login(username, password) {
      if (username === 'admin' && password === 'admin123') {
        localStorage.setItem(AUTH_KEY, 'true');
        Toast.show('Welcome Dr. Ramanathan, logged in successfully.', 'success');
        this.renderView();
        return true;
      } else {
        Toast.show('Invalid credentials! Use demo login: admin / admin123', 'error');
        return false;
      }
    },

    logout() {
      localStorage.removeItem(AUTH_KEY);
      Toast.show('Logged out of Warden Console.', 'info');
      this.renderView();
    },

    renderView() {
      const loginView = document.getElementById('login-view');
      const appContainer = document.getElementById('app-container');

      if (this.isLoggedIn()) {
        loginView.classList.add('hidden');
        appContainer.classList.remove('hidden');
        App.renderAll();
      } else {
        loginView.classList.remove('hidden');
        appContainer.classList.add('hidden');
      }
    }
  };

  // =========================================================================
  // MODAL CONTROLLER
  // =========================================================================
  const Modals = {
    open(modalId) {
      const el = document.getElementById(modalId);
      if (el) {
        el.classList.remove('hidden');
        document.body.classList.add('overflow-hidden');
      }
    },

    close(modalId) {
      const el = document.getElementById(modalId);
      if (el) {
        el.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
      }
    }
  };

  // =========================================================================
  // ROUTER / VIEW SWITCHER
  // =========================================================================
  const Router = {
    currentView: 'dashboard',

    init() {
      document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const target = btn.getAttribute('data-nav');
          if (target) {
            this.navigate(target);
            // Close mobile sidebar if open
            App.closeSidebar();
          }
        });
      });
    },

    navigate(viewName) {
      this.currentView = viewName;

      // Update Navigation Buttons Styling
      document.querySelectorAll('.nav-btn').forEach(btn => {
        const isCurrent = btn.getAttribute('data-nav') === viewName;
        if (isCurrent) {
          btn.className = 'nav-btn w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all text-white bg-slate-800 border-l-4 border-blue-500 shadow-sm';
        } else {
          btn.className = 'nav-btn w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all text-slate-300 hover:text-white hover:bg-slate-800/60 border-l-4 border-transparent';
        }
      });

      // Hide all views and show active view
      document.querySelectorAll('.view-panel').forEach(panel => {
        panel.classList.add('hidden');
      });

      const activePanel = document.getElementById(`view-${viewName}`);
      if (activePanel) {
        activePanel.classList.remove('hidden');
      }

      // Update Page Title
      const pageTitleEl = document.getElementById('page-title');
      if (pageTitleEl) {
        const titles = {
          dashboard: 'Dashboard Overview',
          rooms: 'Room Inventory & Bed Capacity',
          students: 'Student Resident Allocations',
          fees: 'Hostel Fee Ledger & Dues Tracking',
          history: 'Payment History & Receipts',
          settings: 'System & Data Management'
        };
        pageTitleEl.textContent = titles[viewName] || 'Hostel Warden Console';
      }

      // Rerender specific views if needed
      if (viewName === 'dashboard') {
        ChartsManager.update();
      }
    }
  };

  // =========================================================================
  // CHARTS MANAGER
  // =========================================================================
  const ChartsManager = {
    feeChart: null,
    blockChart: null,

    init() {
      this.initFeeChart();
      this.initBlockChart();
    },

    initFeeChart() {
      const ctx = document.getElementById('chart-fee-distribution');
      if (!ctx || typeof Chart === 'undefined') return;

      if (this.feeChart) {
        this.feeChart.destroy();
      }

      this.feeChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: ['Fees Collected', 'Pending Dues'],
          datasets: [{
            data: [260000, 130000],
            backgroundColor: ['#10b981', '#f43f5e'],
            hoverBackgroundColor: ['#059669', '#e11d48'],
            borderWidth: 2,
            borderColor: '#ffffff'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                boxWidth: 12,
                font: { size: 11, family: 'Inter' },
                color: '#475569'
              }
            },
            tooltip: {
              callbacks: {
                label(context) {
                  const val = context.raw || 0;
                  return ` ${context.label}: ₹${Number(val).toLocaleString('en-IN')}`;
                }
              }
            }
          },
          cutout: '72%'
        }
      });
    },

    initBlockChart() {
      const ctx = document.getElementById('chart-block-occupancy');
      if (!ctx || typeof Chart === 'undefined') return;

      if (this.blockChart) {
        this.blockChart.destroy();
      }

      this.blockChart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: ['Block A', 'Block B', 'Block C', 'Block D'],
          datasets: [
            {
              label: 'Occupied Beds',
              data: [2, 3, 0, 0],
              backgroundColor: '#2563eb',
              borderRadius: 6
            },
            {
              label: 'Vacant Beds',
              data: [1, 2, 2, 0],
              backgroundColor: '#e2e8f0',
              borderRadius: 6
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              stacked: true,
              grid: { display: false },
              ticks: { font: { size: 11, family: 'Inter' }, color: '#64748b' }
            },
            y: {
              stacked: true,
              beginAtZero: true,
              ticks: { stepSize: 1, font: { size: 11, family: 'Inter' }, color: '#64748b' },
              grid: { color: '#f1f5f9' }
            }
          },
          plugins: {
            legend: { display: false },
            tooltip: {
              callbacks: {
                label(context) {
                  return ` ${context.dataset.label}: ${context.raw} bed(s)`;
                }
              }
            }
          }
        }
      });
    },

    update() {
      if (!State.data) return;

      // Calculate collected vs pending fees for active students
      let totalCollected = 0;
      let totalPending = 0;

      State.data.students.forEach(st => {
        totalCollected += Number(st.paidFee || 0);
        totalPending += Number(st.balanceDue || 0);
      });

      // Update legends
      const legCol = document.getElementById('chart-legend-collected');
      const legPen = document.getElementById('chart-legend-pending');
      if (legCol) legCol.textContent = Utils.formatCurrency(totalCollected);
      if (legPen) legPen.textContent = Utils.formatCurrency(totalPending);

      if (this.feeChart) {
        this.feeChart.data.datasets[0].data = [totalCollected, totalPending];
        this.feeChart.update();
      }

      // Calculate Block occupancy
      const blocks = ['Block A', 'Block B', 'Block C', 'Block D'];
      const occupiedByBlock = { 'Block A': 0, 'Block B': 0, 'Block C': 0, 'Block D': 0 };
      const vacantByBlock = { 'Block A': 0, 'Block B': 0, 'Block C': 0, 'Block D': 0 };

      State.data.rooms.forEach(r => {
        const b = r.block || 'Block A';
        if (occupiedByBlock[b] === undefined) {
          occupiedByBlock[b] = 0;
          vacantByBlock[b] = 0;
        }
        occupiedByBlock[b] += Number(r.occupied || 0);
        vacantByBlock[b] += Math.max(0, Number(r.capacity || 0) - Number(r.occupied || 0));
      });

      if (this.blockChart) {
        this.blockChart.data.labels = blocks;
        this.blockChart.data.datasets[0].data = blocks.map(b => occupiedByBlock[b] || 0);
        this.blockChart.data.datasets[1].data = blocks.map(b => vacantByBlock[b] || 0);
        this.blockChart.update();
      }
    }
  };

  // =========================================================================
  // MODULE: DASHBOARD & KPIS
  // =========================================================================
  const Dashboard = {
    render() {
      const rooms = State.data.rooms;
      const students = State.data.students;
      const txns = State.data.transactions;

      // 1. Total Rooms & Bed Capacity
      const totalRooms = rooms.length;
      let totalBedCapacity = 0;
      let totalOccupiedBeds = 0;

      rooms.forEach(r => {
        totalBedCapacity += Number(r.capacity || 0);
        totalOccupiedBeds += Number(r.occupied || 0);
      });

      const vacantBeds = Math.max(0, totalBedCapacity - totalOccupiedBeds);
      const activeStudents = students.filter(s => s.status === 'Active').length;

      // 2. Fees Calculations
      let totalFeesExpected = 0;
      let totalFeesCollected = 0;
      let totalFeesPending = 0;
      let studentsWithPending = 0;

      students.forEach(s => {
        totalFeesExpected += Number(s.totalFee || 0);
        totalFeesCollected += Number(s.paidFee || 0);
        totalFeesPending += Number(s.balanceDue || 0);
        if (Number(s.balanceDue || 0) > 0 && s.status === 'Active') {
          studentsWithPending++;
        }
      });

      const realizationRate = totalFeesExpected > 0 
        ? ((totalFeesCollected / totalFeesExpected) * 100).toFixed(1) 
        : '0.0';

      const occupancyPercentage = totalBedCapacity > 0
        ? Math.round((totalOccupiedBeds / totalBedCapacity) * 100)
        : 0;

      // Update KPI DOM
      const kpiTotalRooms = document.getElementById('kpi-total-rooms');
      const kpiBedCapacity = document.getElementById('kpi-bed-capacity');
      const kpiOccupancyRatio = document.getElementById('kpi-occupancy-ratio');
      const kpiVacantBeds = document.getElementById('kpi-vacant-beds');
      const kpiActiveStudents = document.getElementById('kpi-active-students');
      const kpiOccupancyBar = document.getElementById('kpi-occupancy-bar');

      const kpiFeesCollected = document.getElementById('kpi-fees-collected');
      const kpiFeesExpected = document.getElementById('kpi-fees-expected');
      const kpiCollectionRate = document.getElementById('kpi-collection-rate');
      const kpiFeesPending = document.getElementById('kpi-fees-pending');
      const kpiStudentsPendingCount = document.getElementById('kpi-students-pending-count');

      if (kpiTotalRooms) kpiTotalRooms.textContent = `${totalRooms} Rooms`;
      if (kpiBedCapacity) kpiBedCapacity.textContent = `${totalBedCapacity} Total Beds`;
      if (kpiOccupancyRatio) kpiOccupancyRatio.textContent = `${totalOccupiedBeds} / ${totalBedCapacity}`;
      if (kpiVacantBeds) kpiVacantBeds.textContent = vacantBeds;
      if (kpiActiveStudents) kpiActiveStudents.textContent = activeStudents;
      if (kpiOccupancyBar) kpiOccupancyBar.style.width = `${occupancyPercentage}%`;

      if (kpiFeesCollected) kpiFeesCollected.textContent = Utils.formatCurrency(totalFeesCollected);
      if (kpiFeesExpected) kpiFeesExpected.textContent = Utils.formatCurrency(totalFeesExpected);
      if (kpiCollectionRate) kpiCollectionRate.textContent = `${realizationRate}%`;
      if (kpiFeesPending) kpiFeesPending.textContent = Utils.formatCurrency(totalFeesPending);
      if (kpiStudentsPendingCount) kpiStudentsPendingCount.textContent = `${studentsWithPending} student${studentsWithPending === 1 ? '' : 's'}`;

      // Update Fee Management View Stats as well
      const fExpected = document.getElementById('fees-stat-expected');
      const fCollected = document.getElementById('fees-stat-collected');
      const fPending = document.getElementById('fees-stat-pending');
      if (fExpected) fExpected.textContent = Utils.formatCurrency(totalFeesExpected);
      if (fCollected) fCollected.textContent = Utils.formatCurrency(totalFeesCollected);
      if (fPending) fPending.textContent = Utils.formatCurrency(totalFeesPending);

      // Render Recent 5 Transactions in Dashboard
      this.renderRecentTransactions();
    },

    renderRecentTransactions() {
      const tbody = document.getElementById('dashboard-recent-txns');
      if (!tbody) return;

      const txns = [...State.data.transactions]
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .slice(0, 5);

      if (txns.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" class="text-center py-6 text-slate-400">No transactions recorded yet.</td></tr>`;
        return;
      }

      tbody.innerHTML = txns.map(tx => {
        let modeBadge = 'bg-slate-100 text-slate-700';
        if (tx.paymentMode === 'UPI') modeBadge = 'bg-blue-50 text-blue-700 border border-blue-200';
        else if (tx.paymentMode === 'Net Banking') modeBadge = 'bg-purple-50 text-purple-700 border border-purple-200';
        else if (tx.paymentMode === 'Debit/Credit Card') modeBadge = 'bg-amber-50 text-amber-700 border border-amber-200';
        else if (tx.paymentMode === 'Cash') modeBadge = 'bg-emerald-50 text-emerald-700 border border-emerald-200';

        return `
          <tr class="hover:bg-slate-50/80 transition-colors">
            <td class="px-5 py-3 font-mono font-bold text-blue-700">${tx.receiptNo}</td>
            <td class="px-5 py-3 text-slate-500">${Utils.formatDateTime(tx.date)}</td>
            <td class="px-5 py-3 font-semibold text-slate-800">${tx.studentName}</td>
            <td class="px-5 py-3 font-mono text-slate-600">${tx.registerNo}</td>
            <td class="px-5 py-3 font-medium text-slate-700">${tx.roomNo} <span class="text-[10px] text-slate-400">(${tx.block})</span></td>
            <td class="px-5 py-3 font-bold text-emerald-700 text-sm">${Utils.formatCurrency(tx.amountPaid)}</td>
            <td class="px-5 py-3"><span class="px-2 py-0.5 rounded text-[11px] font-semibold ${modeBadge}">${tx.paymentMode}</span></td>
            <td class="px-5 py-3 text-right">
              <button onclick="window.App.Receipt.show('${tx.id}')" 
                      class="px-2.5 py-1 bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-200 hover:border-blue-300 rounded text-xs font-semibold transition-all inline-flex items-center space-x-1">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                <span>View Receipt</span>
              </button>
            </td>
          </tr>
        `;
      }).join('');
    }
  };

  // =========================================================================
  // MODULE: ROOM INVENTORY
  // =========================================================================
  const Rooms = {
    render() {
      const tbody = document.getElementById('rooms-table-body');
      if (!tbody) return;

      const searchTerm = (document.getElementById('filter-room-search')?.value || '').trim().toLowerCase();
      const blockFilter = document.getElementById('filter-room-block')?.value || 'ALL';
      const statusFilter = document.getElementById('filter-room-status')?.value || 'ALL';

      let filtered = State.data.rooms.filter(room => {
        // Search Filter
        const matchesSearch = room.roomNo.toLowerCase().includes(searchTerm) || 
                              room.roomType.toLowerCase().includes(searchTerm) ||
                              room.block.toLowerCase().includes(searchTerm);
        if (!matchesSearch) return false;

        // Block Filter
        if (blockFilter !== 'ALL' && room.block !== blockFilter) return false;

        // Status Filter
        const isFull = room.occupied >= room.capacity;
        if (statusFilter === 'AVAILABLE' && isFull) return false;
        if (statusFilter === 'FULL' && !isFull) return false;

        return true;
      });

      // Update Count
      const countEl = document.getElementById('room-list-count');
      if (countEl) countEl.textContent = `Showing ${filtered.length} of ${State.data.rooms.length} Rooms`;

      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" class="text-center py-8 text-slate-400">No rooms matching the criteria.</td></tr>`;
        return;
      }

      tbody.innerHTML = filtered.map(room => {
        const isFull = room.occupied >= room.capacity;
        const vacantCount = Math.max(0, room.capacity - room.occupied);
        const percent = Math.round((room.occupied / room.capacity) * 100);

        // Status badge
        const statusBadge = isFull
          ? `<span class="badge-full px-2.5 py-0.5 rounded-full text-[11px] font-bold inline-flex items-center space-x-1">
               <span class="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
               <span>FULL (0 Beds)</span>
             </span>`
          : `<span class="badge-available px-2.5 py-0.5 rounded-full text-[11px] font-bold inline-flex items-center space-x-1">
               <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
               <span>AVAILABLE (${vacantCount} left)</span>
             </span>`;

        // Delete button disabled if occupied
        const hasOccupants = room.occupied > 0;
        const deleteBtn = hasOccupants
          ? `<button disabled title="Cannot delete room with active occupants!" 
                     class="px-2.5 py-1 bg-slate-100 text-slate-400 rounded text-xs font-semibold cursor-not-allowed opacity-60">
               Delete
             </button>`
          : `<button onclick="window.App.Rooms.deleteRoom('${room.id}')" 
                     class="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded text-xs font-semibold transition-colors">
               Delete
             </button>`;

        return `
          <tr class="hover:bg-slate-50/80 transition-colors">
            <td class="px-5 py-3 font-bold text-slate-900 text-sm">${room.roomNo}</td>
            <td class="px-5 py-3 font-medium text-slate-700">
              <div>${room.block}</div>
              <div class="text-[10px] text-slate-400 font-normal">${room.floor || 'Floor 1'}</div>
            </td>
            <td class="px-5 py-3 text-slate-800 font-semibold">${room.roomType}</td>
            <td class="px-5 py-3 text-slate-700">${room.capacity} Bed${room.capacity === 1 ? '' : 's'}</td>
            <td class="px-5 py-3">
              <div class="flex items-center space-x-2">
                <span class="font-bold text-slate-800 text-xs">${room.occupied} / ${room.capacity}</span>
                <div class="w-16 bg-slate-200 h-1.5 rounded-full overflow-hidden">
                  <div class="${isFull ? 'bg-rose-500' : 'bg-emerald-500'} h-full rounded-full" style="width: ${percent}%"></div>
                </div>
              </div>
            </td>
            <td class="px-5 py-3 font-mono font-bold text-slate-900">${Utils.formatCurrency(room.annualFee)}</td>
            <td class="px-5 py-3">${statusBadge}</td>
            <td class="px-5 py-3 text-right space-x-2">
              ${deleteBtn}
            </td>
          </tr>
        `;
      }).join('');
    },

    addRoom(formData) {
      const roomNo = formData.roomNo.trim().toUpperCase();

      // Validation 1: Duplicate Room Number
      const exists = State.data.rooms.some(r => r.roomNo.toUpperCase() === roomNo);
      if (exists) {
        Toast.show(`Room ${roomNo} already exists in inventory!`, 'error');
        return false;
      }

      // Validation 2: Capacity
      const capacity = parseInt(formData.capacity, 10);
      if (isNaN(capacity) || capacity < 1 || capacity > 6) {
        Toast.show('Bed capacity must be between 1 and 6.', 'error');
        return false;
      }

      // Validation 3: Annual Fee
      const fee = parseFloat(formData.annualFee);
      if (isNaN(fee) || fee <= 0) {
        Toast.show('Annual fee must be a valid positive amount.', 'error');
        return false;
      }

      const newRoom = {
        id: Utils.generateId('R'),
        roomNo: roomNo,
        block: formData.block,
        roomType: formData.roomType,
        capacity: capacity,
        occupied: 0,
        annualFee: fee,
        floor: formData.floor || '1st Floor',
        amenities: ['Bed & Mattress', 'Study Desk', 'Cupboard', 'WiFi'],
        createdAt: new Date().toISOString()
      };

      State.data.rooms.unshift(newRoom);
      State.save();
      Toast.show(`Room ${newRoom.roomNo} registered successfully with ${capacity} beds.`, 'success');
      Modals.close('modal-add-room');
      return true;
    },

    deleteRoom(roomId) {
      const roomIndex = State.data.rooms.findIndex(r => r.id === roomId);
      if (roomIndex === -1) return;

      const room = State.data.rooms[roomIndex];

      // Strict Validation: Cannot delete if occupied
      if (room.occupied > 0) {
        Toast.show(`Cannot delete room ${room.roomNo} because it currently has ${room.occupied} active occupant(s)!`, 'error');
        return;
      }

      const confirmed = confirm(`Are you sure you want to permanently delete room ${room.roomNo}?`);
      if (!confirmed) return;

      State.data.rooms.splice(roomIndex, 1);
      State.save();
      Toast.show(`Room ${room.roomNo} deleted from inventory.`, 'info');
    }
  };

  // =========================================================================
  // MODULE: STUDENT REGISTRATION & AUTOMATED ALLOCATION
  // =========================================================================
  const Students = {
    render() {
      const tbody = document.getElementById('students-table-body');
      if (!tbody) return;

      const searchTerm = (document.getElementById('filter-student-search')?.value || '').trim().toLowerCase();
      const statusFilter = document.getElementById('filter-student-status')?.value || 'ALL';
      const deptFilter = document.getElementById('filter-student-dept')?.value || 'ALL';

      let filtered = State.data.students.filter(student => {
        // Search Filter
        const matchesSearch = student.fullName.toLowerCase().includes(searchTerm) ||
                              student.registerNo.toLowerCase().includes(searchTerm) ||
                              student.roomNo.toLowerCase().includes(searchTerm);
        if (!matchesSearch) return false;

        // Status Filter
        if (statusFilter !== 'ALL' && student.status !== statusFilter) return false;

        // Department Filter
        if (deptFilter !== 'ALL' && student.department !== deptFilter) return false;

        return true;
      });

      const countEl = document.getElementById('student-list-count');
      if (countEl) countEl.textContent = `Showing ${filtered.length} of ${State.data.students.length} Students`;

      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="10" class="text-center py-8 text-slate-400">No student records match the filters.</td></tr>`;
        return;
      }

      tbody.innerHTML = filtered.map(s => {
        // Student Status Badge
        const isActive = s.status === 'Active';
        const statusBadge = isActive
          ? `<span class="badge-active px-2.5 py-0.5 rounded-full text-[11px] font-bold inline-flex items-center space-x-1">
               <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
               <span>Active Resident</span>
             </span>`
          : `<span class="badge-vacated px-2.5 py-0.5 rounded-full text-[11px] font-bold inline-flex items-center space-x-1">
               <span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
               <span>Vacated</span>
             </span>`;

        // Fee Status Badge
        let feeBadge = '';
        if (s.feeStatus === 'Paid') {
          feeBadge = `<span class="badge-paid px-2 py-0.5 rounded text-[11px] font-bold">PAID</span>`;
        } else if (s.feeStatus === 'Partial') {
          feeBadge = `<span class="badge-partial px-2 py-0.5 rounded text-[11px] font-bold">PARTIAL</span>`;
        } else {
          feeBadge = `<span class="badge-pending px-2 py-0.5 rounded text-[11px] font-bold">PENDING</span>`;
        }

        // Vacate Button
        const vacateBtn = isActive
          ? `<button onclick="window.App.Students.openVacateModal('${s.id}')" 
                     class="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded text-xs font-semibold transition-colors flex items-center space-x-1">
               <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
               <span>Vacate</span>
             </button>`
          : `<span class="text-[11px] text-slate-400 font-medium italic">Vacated on ${Utils.formatDateTime(s.vacatedDate).split(',')[0]}</span>`;

        return `
          <tr class="hover:bg-slate-50/80 transition-colors">
            <td class="px-5 py-3 font-mono font-bold text-blue-700">${s.registerNo}</td>
            <td class="px-5 py-3 font-bold text-slate-900">${s.fullName}</td>
            <td class="px-5 py-3 text-slate-600">
              <div class="font-medium text-slate-700 truncate max-w-[160px]">${s.department}</div>
              <div class="text-[11px] text-slate-400 font-mono">${s.phone}</div>
            </td>
            <td class="px-5 py-3 font-bold text-slate-800">
              <span>${s.roomNo}</span>
              <span class="text-[10px] text-slate-400 block font-normal">${s.block}</span>
            </td>
            <td class="px-5 py-3 text-slate-700 font-medium">${s.roomType}</td>
            <td class="px-5 py-3 font-mono font-semibold text-slate-800">${Utils.formatCurrency(s.totalFee)}</td>
            <td class="px-5 py-3">
              <div class="font-bold text-emerald-700">${Utils.formatCurrency(s.paidFee)}</div>
              <div class="text-[11px] ${s.balanceDue > 0 ? 'text-rose-600 font-bold' : 'text-slate-400'}">
                Due: ${Utils.formatCurrency(s.balanceDue)}
              </div>
            </td>
            <td class="px-5 py-3">${feeBadge}</td>
            <td class="px-5 py-3">${statusBadge}</td>
            <td class="px-5 py-3 text-right">
              ${vacateBtn}
            </td>
          </tr>
        `;
      }).join('');
    },

    populateVacantRoomsDropdown() {
      const selectEl = document.getElementById('student-input-room');
      const pillEl = document.getElementById('allocate-vacant-count-pill');
      const feePreviewEl = document.getElementById('allocate-room-fee-display');
      if (!selectEl) return;

      // Filter STRICTLY rooms that have vacant beds (occupied < capacity)
      const availableRooms = State.data.rooms.filter(r => r.occupied < r.capacity);

      if (pillEl) {
        pillEl.textContent = `${availableRooms.length} room(s) available`;
      }

      if (availableRooms.length === 0) {
        selectEl.innerHTML = `<option value="" disabled selected>No vacant rooms currently available</option>`;
        if (feePreviewEl) feePreviewEl.textContent = '₹0';
        return;
      }

      selectEl.innerHTML = availableRooms.map(r => {
        const bedsLeft = r.capacity - r.occupied;
        return `
          <option value="${r.id}" data-fee="${r.annualFee}" data-room="${r.roomNo}" data-block="${r.block}" data-type="${r.roomType}">
            ${r.roomNo} (${r.block} - ${r.roomType}) • ${bedsLeft} bed${bedsLeft === 1 ? '' : 's'} left • ${Utils.formatCurrency(r.annualFee)}/yr
          </option>
        `;
      }).join('');

      // Update fee preview for the first selected room
      const updateFee = () => {
        const selectedOpt = selectEl.options[selectEl.selectedIndex];
        if (selectedOpt && selectedOpt.dataset.fee) {
          if (feePreviewEl) feePreviewEl.textContent = Utils.formatCurrency(selectedOpt.dataset.fee);
        }
      };

      selectEl.onchange = updateFee;
      updateFee();
    },

    allocateStudent(formData) {
      const regNo = formData.registerNo.trim().toUpperCase();

      // Validation 1: Prevent duplicate Register Numbers
      const exists = State.data.students.some(s => s.registerNo.toUpperCase() === regNo);
      if (exists) {
        Toast.show(`Student with Register No ${regNo} is already registered!`, 'error');
        return false;
      }

      // Validation 2: Ensure room is selected and valid
      const roomId = formData.roomId;
      const targetRoom = State.data.rooms.find(r => r.id === roomId);

      if (!targetRoom) {
        Toast.show('Please select a valid hostel room.', 'error');
        return false;
      }

      // Validation 3: Prevent Overbooking
      if (targetRoom.occupied >= targetRoom.capacity) {
        Toast.show(`Room ${targetRoom.roomNo} is already at full capacity (${targetRoom.capacity}/${targetRoom.capacity})!`, 'error');
        return false;
      }

      // 1. Increment room's occupied count automatically
      targetRoom.occupied += 1;

      // 2. Set total_fee to room's annual fee
      const annualFee = targetRoom.annualFee;

      const newStudent = {
        id: Utils.generateId('S'),
        registerNo: regNo,
        fullName: formData.fullName.trim(),
        department: formData.department,
        phone: formData.phone.trim(),
        roomId: targetRoom.id,
        roomNo: targetRoom.roomNo,
        block: targetRoom.block,
        roomType: targetRoom.roomType,
        allocatedDate: new Date().toISOString(),
        totalFee: annualFee,
        paidFee: 0,
        balanceDue: annualFee,
        feeStatus: 'Pending',
        status: 'Active',
        vacatedDate: null
      };

      State.data.students.unshift(newStudent);
      State.save();

      Toast.show(`Student ${newStudent.fullName} allocated to Room ${targetRoom.roomNo}. Total fee ₹${annualFee.toLocaleString('en-IN')} assigned.`, 'success');
      Modals.close('modal-allocate-student');
      return true;
    },

    // Vacating Process
    studentToVacate: null,

    openVacateModal(studentId) {
      const student = State.data.students.find(s => s.id === studentId);
      if (!student) return;

      this.studentToVacate = student;

      const nameEl = document.getElementById('vacate-student-name');
      const roomEl = document.getElementById('vacate-room-no');
      const warningEl = document.getElementById('vacate-dues-warning');
      const duesAmtEl = document.getElementById('vacate-dues-amount');

      if (nameEl) nameEl.textContent = student.fullName;
      if (roomEl) roomEl.textContent = `${student.roomNo} (${student.block})`;

      if (warningEl && duesAmtEl) {
        if (student.balanceDue > 0) {
          duesAmtEl.textContent = Utils.formatCurrency(student.balanceDue);
          warningEl.classList.remove('hidden');
        } else {
          warningEl.classList.add('hidden');
        }
      }

      Modals.open('modal-vacate-student');
    },

    confirmVacate() {
      if (!this.studentToVacate) return;

      const student = this.studentToVacate;
      const room = State.data.rooms.find(r => r.id === student.roomId || r.roomNo === student.roomNo);

      // 1. Mark student as Vacated
      student.status = 'Vacated';
      student.vacatedDate = new Date().toISOString();

      // 2. Automatically decrement the room's occupied count to free up the bed
      if (room && room.occupied > 0) {
        room.occupied -= 1;
      }

      State.save();
      Toast.show(`Room ${student.roomNo} vacated. Bed successfully freed for new allocations!`, 'success');
      Modals.close('modal-vacate-student');
      this.studentToVacate = null;
    }
  };

  // =========================================================================
  // MODULE: FEE MANAGEMENT & PAYMENT TRACKING
  // =========================================================================
  const Fees = {
    render() {
      const tbody = document.getElementById('fee-table-body');
      if (!tbody) return;

      const searchTerm = (document.getElementById('filter-fee-search')?.value || '').trim().toLowerCase();
      const statusFilter = document.getElementById('filter-fee-status')?.value || 'ALL';

      let filtered = State.data.students.filter(s => {
        // Search
        const matchesSearch = s.fullName.toLowerCase().includes(searchTerm) ||
                              s.registerNo.toLowerCase().includes(searchTerm) ||
                              s.roomNo.toLowerCase().includes(searchTerm);
        if (!matchesSearch) return false;

        // Fee Status
        if (statusFilter !== 'ALL' && s.feeStatus !== statusFilter) return false;

        return true;
      });

      const countEl = document.getElementById('fee-students-count');
      if (countEl) countEl.textContent = `Fee Status Ledger (${filtered.length} students)`;

      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" class="text-center py-8 text-slate-400">No student records match fee filter.</td></tr>`;
        return;
      }

      tbody.innerHTML = filtered.map(s => {
        // Status Badge
        let badge = '';
        if (s.feeStatus === 'Paid') {
          badge = `<span class="badge-paid px-2.5 py-0.5 rounded-full text-[11px] font-bold">PAID</span>`;
        } else if (s.feeStatus === 'Partial') {
          badge = `<span class="badge-partial px-2.5 py-0.5 rounded-full text-[11px] font-bold">PARTIAL</span>`;
        } else {
          badge = `<span class="badge-pending px-2.5 py-0.5 rounded-full text-[11px] font-bold">PENDING</span>`;
        }

        // Action button: Collect Fee if balance > 0
        const actionBtn = s.balanceDue > 0
          ? `<button onclick="window.App.Fees.openPaymentForStudent('${s.id}')" 
                     class="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded text-xs font-semibold transition-colors flex items-center space-x-1">
               <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/></svg>
               <span>Collect Fee</span>
             </button>`
          : `<span class="text-emerald-600 font-bold text-xs inline-flex items-center space-x-1">
               <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
               <span>All Dues Cleared</span>
             </span>`;

        return `
          <tr class="hover:bg-slate-50/80 transition-colors">
            <td class="px-5 py-3 font-mono font-bold text-blue-700">${s.registerNo}</td>
            <td class="px-5 py-3 font-bold text-slate-900">${s.fullName}</td>
            <td class="px-5 py-3 font-medium text-slate-700">${s.roomNo} <span class="text-[10px] text-slate-400">(${s.block})</span></td>
            <td class="px-5 py-3 font-mono font-semibold text-slate-800">${Utils.formatCurrency(s.totalFee)}</td>
            <td class="px-5 py-3 font-mono font-bold text-emerald-700">${Utils.formatCurrency(s.paidFee)}</td>
            <td class="px-5 py-3 font-mono font-bold ${s.balanceDue > 0 ? 'text-rose-600' : 'text-slate-400'}">${Utils.formatCurrency(s.balanceDue)}</td>
            <td class="px-5 py-3">${badge}</td>
            <td class="px-5 py-3 text-right">
              ${actionBtn}
            </td>
          </tr>
        `;
      }).join('');
    },

    populatePaymentModalStudents(preselectedStudentId = null) {
      const selectEl = document.getElementById('payment-input-student');
      if (!selectEl) return;

      // Only show active students who have a positive balance due
      const eligibleStudents = State.data.students.filter(s => s.status === 'Active' && s.balanceDue > 0);

      if (eligibleStudents.length === 0) {
        selectEl.innerHTML = `<option value="" disabled selected>No students with pending balance dues</option>`;
        this.updatePaymentCard(null);
        return;
      }

      selectEl.innerHTML = eligibleStudents.map(s => {
        const isSelected = preselectedStudentId && s.id === preselectedStudentId ? 'selected' : '';
        return `
          <option value="${s.id}" ${isSelected} data-total="${s.totalFee}" data-paid="${s.paidFee}" data-balance="${s.balanceDue}">
            ${s.registerNo} - ${s.fullName} (${s.roomNo}) • Balance Due: ${Utils.formatCurrency(s.balanceDue)}
          </option>
        `;
      }).join('');

      selectEl.onchange = () => {
        const studentId = selectEl.value;
        const student = State.data.students.find(s => s.id === studentId);
        this.updatePaymentCard(student);
      };

      // Trigger update for current selection
      const initialStudent = eligibleStudents.find(s => s.id === (preselectedStudentId || selectEl.value)) || eligibleStudents[0];
      this.updatePaymentCard(initialStudent);
    },

    updatePaymentCard(student) {
      const totalEl = document.getElementById('pay-card-total');
      const paidEl = document.getElementById('pay-card-paid');
      const balanceEl = document.getElementById('pay-card-balance');
      const amountInput = document.getElementById('payment-input-amount');

      if (!student) {
        if (totalEl) totalEl.textContent = '₹0';
        if (paidEl) paidEl.textContent = '₹0';
        if (balanceEl) balanceEl.textContent = '₹0';
        if (amountInput) amountInput.value = '';
        return;
      }

      if (totalEl) totalEl.textContent = Utils.formatCurrency(student.totalFee);
      if (paidEl) paidEl.textContent = Utils.formatCurrency(student.paidFee);
      if (balanceEl) balanceEl.textContent = Utils.formatCurrency(student.balanceDue);

      if (amountInput) {
        amountInput.max = student.balanceDue;
        amountInput.value = student.balanceDue; // default pre-fill full balance
      }
    },

    openPaymentForStudent(studentId) {
      this.populatePaymentModalStudents(studentId);
      Modals.open('modal-record-payment');
    },

    recordPayment(formData) {
      const studentId = formData.studentId;
      const student = State.data.students.find(s => s.id === studentId);

      if (!student) {
        Toast.show('Please select a student.', 'error');
        return false;
      }

      const amount = parseFloat(formData.amount);

      // Validation 1: Amount > 0
      if (isNaN(amount) || amount <= 0) {
        Toast.show('Payment amount must be greater than 0.', 'error');
        return false;
      }

      // Validation 2: Amount <= remaining balance (prevent overpaying!)
      if (amount > student.balanceDue) {
        Toast.show(`Payment of ₹${amount.toLocaleString('en-IN')} exceeds remaining balance due of ₹${student.balanceDue.toLocaleString('en-IN')}!`, 'error');
        return false;
      }

      // 1. Generate unique Receipt Number and timestamp
      const receiptNo = Utils.generateReceiptNo();
      const timestamp = new Date().toISOString();

      // 2. Decrement balance and increment paid
      student.paidFee += amount;
      student.balanceDue -= amount;

      // 3. Update Fee Status
      if (student.balanceDue === 0) {
        student.feeStatus = 'Paid';
      } else {
        student.feeStatus = 'Partial';
      }

      // 4. Create Transaction Record
      const newTxn = {
        id: Utils.generateId('TXN'),
        receiptNo: receiptNo,
        date: timestamp,
        studentId: student.id,
        studentName: student.fullName,
        registerNo: student.registerNo,
        department: student.department,
        phone: student.phone,
        roomId: student.roomId,
        roomNo: student.roomNo,
        block: student.block,
        roomType: student.roomType,
        amountPaid: amount,
        remainingBalance: student.balanceDue,
        totalFee: student.totalFee,
        paymentMode: formData.paymentMode,
        transactionRef: formData.transactionRef.trim() || `TXN-REF-${Math.floor(100000 + Math.random() * 900000)}`,
        remarks: formData.remarks || `Fee payment credited via ${formData.paymentMode}`
      };

      State.data.transactions.unshift(newTxn);
      State.save();

      Toast.show(`Payment of ₹${amount.toLocaleString('en-IN')} recorded for ${student.fullName}. Receipt ${receiptNo} issued!`, 'success');
      Modals.close('modal-record-payment');

      // Prompt to view receipt voucher immediately
      setTimeout(() => {
        App.Receipt.show(newTxn.id);
      }, 350);

      return true;
    }
  };

  // =========================================================================
  // MODULE: PAYMENT HISTORY
  // =========================================================================
  const PaymentHistory = {
    render() {
      const tbody = document.getElementById('history-table-body');
      if (!tbody) return;

      const searchTerm = (document.getElementById('filter-history-search')?.value || '').trim().toLowerCase();
      const modeFilter = document.getElementById('filter-history-mode')?.value || 'ALL';

      let filtered = [...State.data.transactions]
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .filter(tx => {
          // Search
          const matchesSearch = tx.receiptNo.toLowerCase().includes(searchTerm) ||
                                tx.studentName.toLowerCase().includes(searchTerm) ||
                                tx.registerNo.toLowerCase().includes(searchTerm) ||
                                (tx.transactionRef && tx.transactionRef.toLowerCase().includes(searchTerm));
          if (!matchesSearch) return false;

          // Mode
          if (modeFilter !== 'ALL' && tx.paymentMode !== modeFilter) return false;

          return true;
        });

      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="9" class="text-center py-8 text-slate-400">No payment transactions found.</td></tr>`;
        return;
      }

      tbody.innerHTML = filtered.map(tx => {
        let modeBadge = 'bg-slate-100 text-slate-700';
        if (tx.paymentMode === 'UPI') modeBadge = 'bg-blue-50 text-blue-700 border border-blue-200';
        else if (tx.paymentMode === 'Net Banking') modeBadge = 'bg-purple-50 text-purple-700 border border-purple-200';
        else if (tx.paymentMode === 'Debit/Credit Card') modeBadge = 'bg-amber-50 text-amber-700 border border-amber-200';
        else if (tx.paymentMode === 'Cash') modeBadge = 'bg-emerald-50 text-emerald-700 border border-emerald-200';

        return `
          <tr class="hover:bg-slate-50/80 transition-colors">
            <td class="px-5 py-3 font-mono font-bold text-blue-700">${tx.receiptNo}</td>
            <td class="px-5 py-3 text-slate-500 whitespace-nowrap">${Utils.formatDateTime(tx.date)}</td>
            <td class="px-5 py-3 font-semibold text-slate-900">${tx.studentName}</td>
            <td class="px-5 py-3 font-mono text-slate-600">${tx.registerNo}</td>
            <td class="px-5 py-3 font-medium text-slate-700">${tx.roomNo} <span class="text-[10px] text-slate-400">(${tx.block})</span></td>
            <td class="px-5 py-3"><span class="px-2 py-0.5 rounded text-[11px] font-semibold ${modeBadge}">${tx.paymentMode}</span></td>
            <td class="px-5 py-3 font-mono text-slate-500 text-[11px]">${tx.transactionRef || 'N/A'}</td>
            <td class="px-5 py-3 font-mono font-bold text-emerald-700 text-sm">${Utils.formatCurrency(tx.amountPaid)}</td>
            <td class="px-5 py-3 text-right">
              <button onclick="window.App.Receipt.show('${tx.id}')" 
                      class="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded text-xs font-semibold transition-colors inline-flex items-center space-x-1">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                <span>View Receipt</span>
              </button>
            </td>
          </tr>
        `;
      }).join('');
    }
  };

  // =========================================================================
  // MODULE: PRINTABLE DIGITAL RECEIPT
  // =========================================================================
  const Receipt = {
    show(transactionId) {
      const tx = State.data.transactions.find(t => t.id === transactionId);
      if (!tx) {
        Toast.show('Receipt record not found.', 'error');
        return;
      }

      // Populate Receipt DOM
      const receiptNoEl = document.getElementById('receipt-no');
      const receiptDateEl = document.getElementById('receipt-date');
      const studentNameEl = document.getElementById('receipt-student-name');
      const registerNoEl = document.getElementById('receipt-register-no');
      const deptEl = document.getElementById('receipt-dept');
      const phoneEl = document.getElementById('receipt-phone');
      const roomEl = document.getElementById('receipt-room');
      const roomTypeEl = document.getElementById('receipt-room-type');
      const paymentModeEl = document.getElementById('receipt-payment-mode');
      const totalFeeEl = document.getElementById('receipt-total-fee');
      const amountPaidEl = document.getElementById('receipt-amount-paid');
      const remainingBalanceEl = document.getElementById('receipt-remaining-balance');
      const amountWordsEl = document.getElementById('receipt-amount-words');
      const remarksEl = document.getElementById('receipt-remarks');

      if (receiptNoEl) receiptNoEl.textContent = tx.receiptNo;
      if (receiptDateEl) receiptDateEl.textContent = Utils.formatDateTime(tx.date);
      if (studentNameEl) studentNameEl.textContent = tx.studentName;
      if (registerNoEl) registerNoEl.textContent = tx.registerNo;
      if (deptEl) deptEl.textContent = tx.department || 'Undergraduate Engineering';
      if (phoneEl) phoneEl.textContent = tx.phone || '+91 98765 43210';
      if (roomEl) roomEl.textContent = `Room ${tx.roomNo} (${tx.block})`;
      if (roomTypeEl) roomTypeEl.textContent = `${tx.roomType} Accommodation`;
      if (paymentModeEl) paymentModeEl.textContent = `${tx.paymentMode} (Ref: ${tx.transactionRef || 'N/A'})`;

      if (totalFeeEl) totalFeeEl.textContent = Utils.formatCurrency(tx.totalFee);
      if (amountPaidEl) amountPaidEl.textContent = Utils.formatCurrency(tx.amountPaid);
      if (remainingBalanceEl) remainingBalanceEl.textContent = Utils.formatCurrency(tx.remainingBalance);
      if (amountWordsEl) amountWordsEl.textContent = Utils.numberToWords(tx.amountPaid);
      if (remarksEl) remarksEl.textContent = tx.remarks || 'Hostel Term Fee Payment';

      Modals.open('modal-view-receipt');
    },

    print() {
      window.print();
    }
  };

  // =========================================================================
  // APPLICATION CONTROLLER & EVENT WIRING
  // =========================================================================
  const App = {
    Router,
    Modals,
    Rooms,
    Students,
    Fees,
    Receipt,

    init() {
      // 1. Initialize State
      State.init();
      Toast.init();

      // 2. Wire Auth
      this.wireAuthEvents();

      // 3. Wire UI Handlers
      this.wireUIEvents();

      // 4. Initialize Router & Charts
      Router.init();
      ChartsManager.init();

      // 5. Initial View Check
      Auth.renderView();
    },

    wireAuthEvents() {
      const loginForm = document.getElementById('login-form');
      const btnFillDemo = document.getElementById('btn-fill-demo');
      const btnLogout = document.getElementById('btn-logout');

      if (loginForm) {
        loginForm.addEventListener('submit', e => {
          e.preventDefault();
          const u = document.getElementById('login-username').value.trim();
          const p = document.getElementById('login-password').value.trim();
          Auth.login(u, p);
        });
      }

      if (btnFillDemo) {
        btnFillDemo.addEventListener('click', () => {
          const u = document.getElementById('login-username');
          const p = document.getElementById('login-password');
          if (u) u.value = 'admin';
          if (p) p.value = 'admin123';
          Toast.show('Demo credentials filled: admin / admin123', 'info');
        });
      }

      if (btnLogout) {
        btnLogout.addEventListener('click', () => {
          Auth.logout();
        });
      }
    },

    wireUIEvents() {
      // Mobile Drawer Toggle
      const btnOpenSidebar = document.getElementById('btn-open-sidebar');
      const btnCloseSidebar = document.getElementById('btn-close-sidebar');
      const sidebar = document.getElementById('sidebar');
      const sidebarBackdrop = document.getElementById('sidebar-backdrop');

      const openDrawer = () => {
        if (sidebar) sidebar.classList.remove('-translate-x-full');
        if (sidebarBackdrop) sidebarBackdrop.classList.remove('hidden');
      };

      const closeDrawer = () => {
        if (sidebar) sidebar.classList.add('-translate-x-full');
        if (sidebarBackdrop) sidebarBackdrop.classList.add('hidden');
      };

      if (btnOpenSidebar) btnOpenSidebar.addEventListener('click', openDrawer);
      if (btnCloseSidebar) btnCloseSidebar.addEventListener('click', closeDrawer);
      if (sidebarBackdrop) sidebarBackdrop.addEventListener('click', closeDrawer);
      this.closeSidebar = closeDrawer;

      // Quick Header Buttons
      document.getElementById('btn-quick-allocate')?.addEventListener('click', () => {
        Students.populateVacantRoomsDropdown();
        Modals.open('modal-allocate-student');
      });

      document.getElementById('btn-quick-fee')?.addEventListener('click', () => {
        Fees.populatePaymentModalStudents();
        Modals.open('modal-record-payment');
      });

      // Rooms Buttons & Modals
      document.getElementById('btn-open-add-room-modal')?.addEventListener('click', () => {
        Modals.open('modal-add-room');
      });

      document.getElementById('form-add-room')?.addEventListener('submit', e => {
        e.preventDefault();
        const roomNo = document.getElementById('room-input-no').value;
        const block = document.getElementById('room-input-block').value;
        const roomType = document.getElementById('room-input-type').value;
        const capacity = document.getElementById('room-input-capacity').value;
        const annualFee = document.getElementById('room-input-fee').value;
        const floor = document.getElementById('room-input-floor').value;

        Rooms.addRoom({ roomNo, block, roomType, capacity, annualFee, floor });
      });

      // Filter Rooms
      document.getElementById('filter-room-search')?.addEventListener('input', () => Rooms.render());
      document.getElementById('filter-room-block')?.addEventListener('change', () => Rooms.render());
      document.getElementById('filter-room-status')?.addEventListener('change', () => Rooms.render());

      // Students Buttons & Modals
      document.getElementById('btn-open-allocate-modal')?.addEventListener('click', () => {
        Students.populateVacantRoomsDropdown();
        Modals.open('modal-allocate-student');
      });

      document.getElementById('form-allocate-student')?.addEventListener('submit', e => {
        e.preventDefault();
        const registerNo = document.getElementById('student-input-reg').value;
        const fullName = document.getElementById('student-input-name').value;
        const department = document.getElementById('student-input-dept').value;
        const phone = document.getElementById('student-input-phone').value;
        const roomId = document.getElementById('student-input-room').value;

        Students.allocateStudent({ registerNo, fullName, department, phone, roomId });
      });

      // Filter Students
      document.getElementById('filter-student-search')?.addEventListener('input', () => Students.render());
      document.getElementById('filter-student-status')?.addEventListener('change', () => Students.render());
      document.getElementById('filter-student-dept')?.addEventListener('change', () => Students.render());

      // Confirm Vacate Button
      document.getElementById('btn-confirm-vacate')?.addEventListener('click', () => {
        Students.confirmVacate();
      });

      // Fee Management & Payment Modal
      document.getElementById('btn-open-payment-modal')?.addEventListener('click', () => {
        Fees.populatePaymentModalStudents();
        Modals.open('modal-record-payment');
      });

      document.getElementById('form-record-payment')?.addEventListener('submit', e => {
        e.preventDefault();
        const studentId = document.getElementById('payment-input-student').value;
        const amount = document.getElementById('payment-input-amount').value;
        const paymentMode = document.getElementById('payment-input-mode').value;
        const transactionRef = document.getElementById('payment-input-ref').value;

        Fees.recordPayment({
          studentId,
          amount,
          paymentMode,
          transactionRef,
          remarks: `Hostel room fee installment via ${paymentMode}`
        });
      });

      // Quick Payment Chips
      document.getElementById('btn-pay-full')?.addEventListener('click', () => {
        const studentId = document.getElementById('payment-input-student').value;
        const student = State.data.students.find(s => s.id === studentId);
        if (student) {
          document.getElementById('payment-input-amount').value = student.balanceDue;
        }
      });

      document.getElementById('btn-pay-half')?.addEventListener('click', () => {
        const studentId = document.getElementById('payment-input-student').value;
        const student = State.data.students.find(s => s.id === studentId);
        if (student) {
          document.getElementById('payment-input-amount').value = Math.round(student.balanceDue / 2);
        }
      });

      document.getElementById('btn-pay-25k')?.addEventListener('click', () => {
        const studentId = document.getElementById('payment-input-student').value;
        const student = State.data.students.find(s => s.id === studentId);
        if (student) {
          const val = Math.min(25000, student.balanceDue);
          document.getElementById('payment-input-amount').value = val;
        }
      });

      // Filter Fees
      document.getElementById('filter-fee-search')?.addEventListener('input', () => Fees.render());
      document.getElementById('filter-fee-status')?.addEventListener('change', () => Fees.render());

      // Filter History
      document.getElementById('filter-history-search')?.addEventListener('input', () => PaymentHistory.render());
      document.getElementById('filter-history-mode')?.addEventListener('change', () => PaymentHistory.render());

      // Print Receipt Button
      document.getElementById('btn-print-receipt')?.addEventListener('click', () => {
        Receipt.print();
      });

      // Data Management Settings
      document.getElementById('btn-reset-demo')?.addEventListener('click', () => {
        if (confirm('Are you sure you want to restore the pre-seeded demo database? Current modifications will be reset.')) {
          State.resetToSeed();
          Toast.show('Pre-seeded sample database successfully restored!', 'success');
        }
      });

      document.getElementById('btn-export-json')?.addEventListener('click', () => {
        const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(State.data, null, 2));
        const downloadAnchor = document.createElement('a');
        downloadAnchor.setAttribute('href', dataStr);
        downloadAnchor.setAttribute('download', `Hostel_Warden_Backup_${new Date().toISOString().slice(0, 10)}.json`);
        document.body.appendChild(downloadAnchor);
        downloadAnchor.click();
        downloadAnchor.remove();
        Toast.show('Database JSON exported successfully.', 'info');
      });
    },

    renderAll() {
      if (!State.data) return;
      Dashboard.render();
      Rooms.render();
      Students.render();
      Fees.render();
      PaymentHistory.render();
      ChartsManager.update();
    }
  };

  // Expose to window for inline onclick handlers
  window.App = App;

  // Initialize on DOMContentLoaded
  document.addEventListener('DOMContentLoaded', () => {
    App.init();
  });
})();
