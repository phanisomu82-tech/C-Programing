# 🏨 Hostel Room Allocation & Fee Management System
### University Hostel Warden & Administration Portal

A modern, responsive, full-stack web application designed for university hostel wardens and administrative staff. Built with a clean SaaS dashboard aesthetic (dark navy sidebar, light slate background `#f1f5f9`, white rounded cards, Inter typography, and color-coded status badges).

---

## 🚀 Key Modules & Capabilities

### 1. 🔐 Admin Authentication
- **Secure Access Control**: Dedicated login interface for the Hostel Warden / Administrative Officer.
- **Demo Credentials**:
  - **Username**: `admin`
  - **Password**: `admin123`
- **1-Click Auto-Fill**: Instant credential population for quick testing.
- **Session Persistence**: Warden session stored securely with instant logout capability in the sidebar.

### 2. 📊 Live Executive Dashboard & Visual Analytics
- **4 Real-Time KPI Cards**:
  1. **Total Rooms & Bed Capacity**: Room count, total beds, and distribution across blocks.
  2. **Occupancy Status**: Live occupied beds vs. vacant beds, active resident student count, and progress bar indicator.
  3. **Fees Collected vs Expected**: Total revenue collected, total expected fees, and fee realization rate.
  4. **Pending Fee Dues**: Outstanding unpaid balances with live counter of students with pending dues.
- **Visual Charts**:
  - **Doughnut Chart**: Live fee realization comparison (Collected vs. Pending Outstanding Dues).
  - **Stacked Bar Chart**: Bed occupancy distribution per hostel building block (Block A, Block B, Block C, Block D).
- **Recent Fee Transactions Table**: Displays the 5 latest payments with a 1-click **"View Receipt"** shortcut.

### 3. 🏢 Room Inventory Management
- **Room Registration Form**:
  - Room No (e.g., `A-101`, `B-205`)
  - Hostel Block (Block A, Block B, Block C, Block D)
  - Room Classification (`Single AC`, `Double AC`, `Double Non-AC`, `Triple Non-AC`, `Four Bed Non-AC`)
  - Bed Capacity (1 to 6 beds)
  - Annual Hostel Fee (in ₹)
  - Floor Level
- **Validation**:
  - Prevents duplicate room numbers.
  - Enforces capacity between 1 and 6.
  - Validates positive fee amounts.
- **Live Inventory Table**:
  - Real-time occupancy tracker (e.g., `1 / 2 beds`) with color progress bars.
  - Status badges: <span style="color:#059669; font-weight:bold;">AVAILABLE (Green)</span> and <span style="color:#dc2626; font-weight:bold;">FULL (Red)</span>.
  - **Protection Guard**: Delete button is disabled and blocked if a room currently has active occupants.
- **Pre-Seeded Sample Data**: Ships with 5 realistic rooms across blocks A, B, and C.

### 4. 🎓 Student Registration & Automated Room Allocation
- **Resident Allocation Form**:
  - Register / Roll Number (e.g., `2024CS101`)
  - Full Student Name
  - Department (CSE, ECE, ME, EEE, IT, Civil)
  - Phone Number
  - **Vacant Room Dropdown**: Strictly filters and displays **ONLY** rooms that currently have vacant beds (`occupied < capacity`).
- **Automated Calculations on Allocation**:
  - Increments the room's occupied count (`occupied += 1`).
  - Sets the student's `total_fee` to the room's annual fee.
  - Sets initial `paid_fee = 0`, `balance_due = total_fee`, and status to `Active`.
- **Live Resident Directory**:
  - Real-time search filter by Student Name, Register Number, or Room.
  - Filters by Status (Active Resident, Vacated) and Department.
- **Automated Room Vacate Workflow**:
  - Clicking **"Vacate"** prompts confirmation and checks if any outstanding dues remain.
  - Marks student as `Vacated` and automatically decrements the room's occupied count (`occupied -= 1`), immediately releasing the bed for new allocations.

### 5. 💳 Fee Management & Payment Tracking
- **Payment Collection Form**:
  - Select Active Student dropdown showing remaining balance due.
  - Amount validation: Enforces `amount > 0` and **strictly prohibits overpayments** (`amount <= balanceDue`).
  - Quick amount helper chips: `Full Balance`, `50%`, and `₹25,000`.
  - Payment Modes: `UPI`, `Debit/Credit Card`, `Net Banking`, and `Cash`.
  - Transaction Reference / Remarks input.
- **Automated Processing**:
  - Generates unique Receipt Voucher numbers (e.g., `RCPT-8A4F2C1B`).
  - Deducts from `balanceDue` and adds to `paidFee`.
  - Automatically updates student status badge:
    - <span style="color:#059669; font-weight:bold;">PAID (Green)</span> when balance is 0.
    - <span style="color:#d97706; font-weight:bold;">PARTIAL (Yellow)</span> when partially paid.
    - <span style="color:#dc2626; font-weight:bold;">PENDING (Red)</span> when unpaid.
  - Appends record to Payment Ledger and immediately recalculates all KPI cards and charts.
- **Ledger & Table**: Quick "Collect Fee" shortcut button on every resident row.

### 6. 📜 Official Printable Digital Fee Receipt
- **Formal Institutional Letterhead**: Apex University of Technology Hostel Warden Office.
- **Receipt Details**:
  - Unique Receipt Voucher No & Timestamp
  - Resident Name, Register No, Department & Contact Phone
  - Allocated Room & Block
  - Accommodation Classification
  - Detailed Financial Ledger Table
  - **Amount in Words** (Auto-converted to Indian Rupee word format, e.g. *"Eighty Thousand Rupees Only"*)
  - Payment Mode & UTR / Transaction Reference
  - Digital Warden Seal & Verification Stamp
- **Print / Save as PDF**:
  - One-click print engine (`window.print()`).
  - Includes dedicated `@media print` CSS that strips sidebars, navigation bars, and buttons to generate a crisp A4/Letter document.

### 7. 🔔 Toast Feedback & UX
- Smooth stackable toast alerts for all success, validation, and error states.
- Auto-dismissing with progress indicator or dismiss on click.
- Responsive mobile drawer with hamburger toggle.

---

## 🛠️ Project Structure

```
hostel-management-system/
├── index.html           # Main single-page application & modal templates
├── styles.css           # Styling, design tokens, badge styles & print rules
├── app.js               # Reactive state store, calculations, charts & controllers
├── start-server.ps1     # Native PowerShell HTTP server (zero external dependencies)
├── start-server.bat     # Windows 1-click batch launcher
└── README.md            # Comprehensive project documentation
```

---

## 🖥️ How to Run & Use the Application

### Option 1: Direct File Open (Recommended & Instant)
Open `index.html` directly in any web browser (Google Chrome, Microsoft Edge, Mozilla Firefox, or Safari):
```
file:///C:/Users/abhijay%20M/.gemini/antigravity/scratch/hostel-management-system/index.html
```

### Option 2: Local Built-in HTTP Server (No Node.js or Python required!)
Double-click `start-server.bat` or run in PowerShell:
```powershell
powershell -ExecutionPolicy Bypass -File .\start-server.ps1
```
This starts a local HTTP server at `http://localhost:8080/` and automatically opens the browser.

---

## ⚙️ Demo Data & Reset
The application comes pre-loaded with realistic sample data:
- **5 Rooms**: A-101 (Single AC), A-102 (Double AC), B-201 (Double Non-AC), B-202 (Triple Non-AC), C-301 (Double AC).
- **5 Students**: With various payment statuses (Paid, Partial, Pending).
- **4 Verified Transactions**: With viewable and printable receipts.

To restore the original demo records at any time, navigate to **System & Data** in the left sidebar and click **"Reset Database to Demo State"**. You can also export a full JSON backup of the system anytime.
